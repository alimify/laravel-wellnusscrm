@extends('layouts.admin.app')

@section('title','Show')

@push('css')


@endpush


@section('content')
@endsection


@push('script')

@endpush
