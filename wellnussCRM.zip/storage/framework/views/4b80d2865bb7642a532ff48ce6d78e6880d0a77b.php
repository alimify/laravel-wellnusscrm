<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- FAVICON Icon -->
    <link rel="icon" href="../../../../favicon.ico">

    <!-- Title -->
    <title>Leads Management</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/admin/dashboard.css')); ?>" rel="stylesheet">

</head>

<body>
<?php echo $__env->make('layouts.admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container-fluid justify-content-center mt-3">
    <div class="row">


        <main role="main" class="col-12 px-4">
            <?php echo $__env->make('layouts.admin.partials.notice', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if($leads->count()): ?>
                <h2>Leads (<?php echo e($leads->count()); ?>)</a></h2>

                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Product ID</th>
                                <th>Product Code</th>
                                <th>DateTime</th>
                                <th>Customer</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Order Id</th>
                                <th>Status</th>
                                <th>Note</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($lead->id); ?></td>
                                    <td><?php echo e($lead->product_id); ?></td>
                                    <td><?php echo e($lead->Product->code); ?></td>
                                    <td><?php echo e($lead->created_at); ?></td>
                                    <td><?php echo e($lead->name); ?></td>
                                    <td><?php echo e($lead->phone); ?></td>
                                    <td><?php echo e($lead->email); ?></td>
                                    <td><?php echo e($lead->address); ?></td>
                                    <td><?php echo e($lead->order_id); ?></td>
                                    <td><span class="<?php echo e($lead->CallerStatus->class); ?>"><?php echo e($lead->CallerStatus->title); ?></span></td>
                                    <td><?php echo e($lead->note); ?><br/><a href="javascript:void(0)" data-src="<?php echo e($lead->id); ?>" data-content="<?php echo e($lead->note); ?>" class="text-center note-modal" data-toggle="modal" data-target="#noteModal"><i class="fa fa-plus"></i></a></td>
                                    <td>

                                    <a href="<?php echo e(route('caller.lead.status',['id' => $lead->id, 'status' => 1])); ?>"><i class="fa fa-check" aria-hidden="true"></i></a>
                                    <a href="<?php echo e(route('caller.lead.status',['id' => $lead->id, 'status' => 2])); ?>"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
                                    <a href="<?php echo e(route('caller.lead.status',['id' => $lead->id, 'status' => 3])); ?>"><i class="fa fa-pause" aria-hidden="true"></i></a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

            <?php else: ?>
                <div class="text-warning text-center">No data available.</div>
        <?php endif; ?>

        <!-- Modal -->
            <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" aria-labelledby="noteModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form action="<?php echo e(route('caller.lead.note.edit')); ?>" method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title" id="noteModalLabel">Note</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <input id="modal-note-id" type="hidden" name="id">
                                <textarea class="form-control" id="modal-note" name="note"></textarea>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    $(document).ready(function() {

        $('#example').DataTable({
            "ordering": false,
            "info": false,
            "lengthChange": false
        });


        $(".note-modal").click(function () {
            $("#modal-note-id").val(this.dataset.src)
            $("#modal-note").text(this.dataset.content)
        })
    })
</script>

<!-- Icons -->

</body>
</html>
