<?php $__env->startSection('title','Show'); ?>

<?php $__env->startPush('css'); ?>

<script src="<?php echo e(asset('js/admin/piechart.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <span class="btn btn-status-confirm"></span> Confirm
        <span class="btn btn-status-cancel"></span> Cancel
        <span class="btn btn-status-hold"></span> Hold
        <span class="btn btn-status-trash"></span> Trash
    </div>
    <div id="piechart" style="height: 500px;"></div>


    <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
            <tr>
                <th>#ID</th>
                <th>Order ID</th>
                <th>DateTime</th>
                <th>Supplier</th>
                <th>Customer</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Address</th>
                <th>Status Admin</th>
                <th>Status Caller</th>
                <th>Note</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($lead->supplier_serial); ?></td>
                    <td><?php echo e($lead->order_id); ?></td>
                    <td><?php echo e($lead->created_at); ?></td>
                    <td><?php echo e($lead->Supplier->name??''); ?></td>
                    <td><?php echo e($lead->name); ?></td>
                    <td><?php echo e($lead->phone); ?></td>
                    <td><?php echo e($lead->email); ?></td>
                    <td><?php echo e($lead->address); ?></td>
                    <td><span class="<?php echo e($lead->AdminStatus->class??''); ?>" title="<?php echo e($lead->AdminStatus->title??''); ?>"></span></td>
                    <td><span class="<?php echo e($lead->CallerStatus->class??''); ?>" title="<?php echo e($lead->CallerStatus->title??''); ?>"></span></td>
                    <td><?php echo e($lead->note); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {

            google.charts.load("current", {packages: ["corechart"]});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable(<?php echo json_encode($chart); ?>);

                var options = {
                    title: `<?php echo e($product->name); ?> #<?php echo e($product->id); ?>`,
                    is3D: true,
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                chart.draw(data, options);
            }

            $('#example').DataTable({
                destroy: true,
                bDestroy: true,
                "ordering": false,
                "info": false,
                "lengthChange": false
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>