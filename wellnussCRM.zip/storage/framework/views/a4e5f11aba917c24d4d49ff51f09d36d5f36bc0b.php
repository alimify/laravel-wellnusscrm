<?php $__env->startSection('title','User'); ?>

<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-success mt-4 mb-4">Add</a>
    <?php if($users->count() || $trashes->count()): ?>
    <h2>All Users</a></h2>
    <a href="<?php echo e(route('admin.user.index')); ?>">Active Users (<?php echo e($users->count()); ?>)</a>
    - <a href="<?php echo e(route('admin.user.index',['type' => 'trash'])); ?>">Trash (<?php echo e($trashes->count()); ?>)</a>
    - <a href="<?php echo e(route('admin.user.restore.all')); ?>">Restore All</a>

    <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
            <tr>
                <th>#ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>

        <?php $__currentLoopData = (isset($_REQUEST['type']) && $_REQUEST['type'] == 'trash' ? $trashes : $users); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->Userextra->phone); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->Role->title); ?></td>
                <td>
                    <?php if(isset($_REQUEST['type']) && $_REQUEST['type'] == 'trash'): ?>

                        <a href="<?php echo e(route('admin.user.restore.single',$user->id)); ?>" class="restore-item" data-src="<?php echo e($user->id); ?>"><i class="fa fa-undo" aria-hidden="true"></i></a>

                    <?php else: ?>

                    <a href="<?php echo e(route('admin.user.edit',$user->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    <?php endif; ?>

                    <a href="javascript:void(0)" class="delete-item" data-src="<?php echo e($user->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
            <?php else: ?>
            <div class="text-warning text-center">No data available.</div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "ordering": false,
            "info":     false,
            "lengthChange": false
        });


        $(".delete-item").click(function () {

            let deleteForm = document.createElement('form'),
                currentURL = `<?php echo e(route('admin.user.destroy','deleteid')); ?>`,
                deleteURL = currentURL.replace('deleteid',this.dataset.src),
                csrfInput = document.createElement('input'),
                methodInput = document.createElement('input')
            deleteForm.style.display = 'none';
            deleteForm.method = 'POST'
            deleteForm.action = deleteURL
            csrfInput.name = `_token`
            csrfInput.value = `<?php echo e(csrf_token()); ?>`
            methodInput.name = `_method`
            methodInput.value = `DELETE`
            deleteForm.appendChild(csrfInput)
            deleteForm.appendChild(methodInput)
            document.body.appendChild(deleteForm)
            deleteForm.submit()
        })


    } );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>