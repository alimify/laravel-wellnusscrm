<?php $__env->startSection('title','Edit Product'); ?>

<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add Product</h1>
    </div>

    <div class="col-xs-10 col-md-6 mb-5">
        <form action="<?php echo e(route('admin.product.update',$product->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Code</label>
                <input type="text" name="code" class="form-control" id="code" value="<?php echo e($product->code); ?>">
            </div>

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e($product->name); ?>">
            </div>
            <div class="form-group">
                <label for="email">Note</label>
                <textarea class="form-control" name="note"><?php echo e($product->note); ?></textarea>
            </div>

            <div class="form-group">
                <label for="phone">Image</label>
                <img src="<?php echo e(asset($product->image)); ?>">
                <input type="file" name="image" class="form-control-file" id="image">
            </div>

            <!--<div class="form-group">
                <label for="phone" class="form-label form-control-file">Status</label>
                <input type="checkbox" name="status" class="form-check-inline" id="status" value="1"> <label for="status" class="form-check-label">Active</label>
            </div>-->
            <a class="btn btn-danger" href="<?php echo e(route('admin.user.index')); ?>">Back</a> <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>