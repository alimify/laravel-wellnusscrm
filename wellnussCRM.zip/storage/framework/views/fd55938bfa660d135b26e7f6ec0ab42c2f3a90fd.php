<?php $__env->startSection('title','Leads'); ?>

<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <?php if($leads->count() || $trashes->count()): ?>
        <h2>Leads</a></h2>
        <a href="<?php echo e(route('admin.lead.index')); ?>">Leads (<?php echo e($leads->count()); ?>)</a>
        - <a href="<?php echo e(route('admin.lead.index',['type' => 'trash'])); ?>">Trash (<?php echo e($trashes->count()); ?>)</a>
        - <a href="<?php echo e(route('admin.lead.restore.all')); ?>">Restore All</a>

        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Product ID</th>
                    <th>Product Code</th>
                    <th>DateTime</th>
                    <th>Supplier</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Order Id</th>
                    <th>Status Admin</th>
                    <th>Status Caller</th>
                    <th>Note</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = (isset($_REQUEST['type']) && $_REQUEST['type'] == 'trash' ? $trashes : $leads); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($lead->id); ?></td>
                        <td><?php echo e($lead->product_id); ?></td>
                        <td><?php echo e($lead->Product->code); ?></td>
                        <td><?php echo e($lead->created_at); ?></td>
                        <td><?php echo e($lead->Supplier->name); ?></td>
                        <td><?php echo e($lead->name); ?></td>
                        <td><?php echo e($lead->phone); ?></td>
                        <td><?php echo e($lead->email); ?></td>
                        <td><?php echo e($lead->address); ?></td>
                        <td><?php echo e($lead->order_id); ?></td>
                        <td><span class="<?php echo e($lead->AdminStatus->class); ?>"><?php echo e($lead->AdminStatus->title); ?></span></td>
                        <td><span class="<?php echo e($lead->CallerStatus->class); ?>"><?php echo e($lead->CallerStatus->title); ?></span></td>
                        <td><?php echo e($lead->note); ?><br/><a href="javascript:void(0)" data-src="<?php echo e($lead->id); ?>" data-content="<?php echo e($lead->note); ?>" class="text-center note-modal" data-toggle="modal" data-target="#noteModal"><i class="fa fa-plus"></i></a></td>
                        <td>
                            <?php if(isset($_REQUEST['type']) && $_REQUEST['type'] == 'trash'): ?>

                                <a href="<?php echo e(route('admin.lead.restore.single',$lead->id)); ?>" class="restore-item" data-src="<?php echo e($lead->id); ?>"><i class="fa fa-undo" aria-hidden="true"></i></a>

                            <?php else: ?>

                                <a href="<?php echo e(route('admin.lead.status',['id' => $lead->id, 'status' => 1])); ?>"><i class="fa fa-check" aria-hidden="true"></i></a>
                                <a href="<?php echo e(route('admin.lead.status',['id' => $lead->id, 'status' => 2])); ?>"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
                                <a href="<?php echo e(route('admin.lead.status',['id' => $lead->id, 'status' => 3])); ?>"><i class="fa fa-pause" aria-hidden="true"></i></a>

                            <?php endif; ?>

                            <a href="javascript:void(0)" class="delete-item" data-src="<?php echo e($lead->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-warning text-center">No data available.</div>
    <?php endif; ?>

    <!-- Modal -->
    <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" aria-labelledby="noteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.lead.note.edit')); ?>" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="noteModalLabel">Note</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input id="modal-note-id" type="hidden" name="id">
                       <textarea class="form-control" id="modal-note" name="note"></textarea>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "ordering": false,
                "info":     false,
                "lengthChange": false
            });


            $(".delete-item").click(function () {

                let deleteForm = document.createElement('form'),
                    currentURL = `<?php echo e(route('admin.lead.destroy','deleteid')); ?>`,
                    deleteURL = currentURL.replace('deleteid',this.dataset.src),
                    csrfInput = document.createElement('input'),
                    methodInput = document.createElement('input')
                deleteForm.style.display = 'none';
                deleteForm.method = 'POST'
                deleteForm.action = deleteURL
                csrfInput.name = `_token`
                csrfInput.value = `<?php echo e(csrf_token()); ?>`
                methodInput.name = `_method`
                methodInput.value = `DELETE`
                deleteForm.appendChild(csrfInput)
                deleteForm.appendChild(methodInput)
                document.body.appendChild(deleteForm)
                deleteForm.submit()
            })


        $(".note-modal").click(function () {
            $("#modal-note-id").val(this.dataset.src)
            $("#modal-note").text(this.dataset.content)
        })


        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>